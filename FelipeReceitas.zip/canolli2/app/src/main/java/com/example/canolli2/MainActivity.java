package com.example.canolli2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;



public class MainActivity extends AppCompatActivity {

    // Declaração dos componentes da interface
    private EditText campoEmail;
    private EditText campoSenha;
    private Button botaoLogin;
    private Button botaoRegistro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Habilita o modo Edge-to-Edge (tela cheia)
        EdgeToEdge.enable(this);

        // Define o layout da activity
        setContentView(R.layout.activity_main);

        // Configura o listener para ajustar padding com as barras do sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicializa os componentes da interface
        inicializarComponentes();

        // Configura os listeners dos botões
        configurarEventos();
    }

    /**
     * Método para inicializar todos os componentes da interface
     */
    private void inicializarComponentes() {
        // Vincula os componentes do layout aos objetos Java
        campoEmail = findViewById(R.id.CampoEmail);
        campoSenha = findViewById(R.id.CampoSenha);
        botaoLogin = findViewById(R.id.Login);
        botaoRegistro = findViewById(R.id.BotaoRegistro);
    }

    /**
     * Método para configurar os eventos de clique dos botões
     */
    private void configurarEventos() {
        // Configura o evento de clique do botão Login
        botaoLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realizarLogin();
            }
        });

        // Configura o evento de clique do botão Registrar-se
        botaoRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realizarRegistro();
            }
        });
    }

    /**
     * Método para realizar o login do usuário
     */
    private void realizarLogin() {
        // Obtém o texto digitado nos campos
        String email = campoEmail.getText().toString().trim();
        String senha = campoSenha.getText().toString().trim();

        // Valida se os campos não estão vazios
        if (email.isEmpty()) {
            campoEmail.setError("Por favor, digite seu email");
            campoEmail.requestFocus();
            return;
        }

        if (senha.isEmpty()) {
            campoSenha.setError("Por favor, digite sua senha");
            campoSenha.requestFocus();
            return;
        }

        // Valida o formato do email
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            campoEmail.setError("Email inválido");
            campoEmail.requestFocus();
            return;
        }

        // Aqui você implementaria a lógica de autenticação
        // Por exemplo, verificar com Firebase, API, banco de dados local, etc.

        // TODO: Implementar autenticação real
        // Por enquanto, se as validações passarem, redireciona para a tela principal

        // Feedback ao usuário
        Toast.makeText(this, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show();

        // Redireciona para a tela3 (tela principal)
        Intent intent = new Intent(MainActivity.this, tela3.class);

        // Opcional: Passar dados do usuário para a próxima tela
        intent.putExtra("email", email);

        // Inicia a Tela3
        startActivity(intent);

        // Opcional: Finaliza a MainActivity para que o usuário não volte ao apertar "voltar"
        // finish();
    }

    /**
     * Método para navegar para a tela de registro
     */
    private void realizarRegistro() {
        // Cria um Intent para navegar para a Tela2 (tela de cadastro)
        Intent intent = new Intent(MainActivity.this, Tela2.class);

        // Inicia a nova Activity
        startActivity(intent);
    }

    /**
     * Método para limpar os campos após operação bem-sucedida
     */
    private void limparCampos() {
        campoEmail.setText("");
        campoSenha.setText("");
        campoEmail.requestFocus();
    }
}