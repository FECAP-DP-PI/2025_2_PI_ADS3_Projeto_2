package com.example.canolli2;

import java.io.Serializable;

/**
 * Classe modelo para representar uma Receita
 * Implementa Serializable para poder ser passada entre Activities
 */
public class Receita implements Serializable {

    // Atributos da receita
    private String nome;
    private String preparo;
    private String tempo;

    /**
     * Construtor vazio
     */
    public Receita() {
    }

    /**
     * Construtor com todos os parâmetros
     * @param nome Nome da receita
     * @param preparo Modo de preparo da receita
     * @param tempo Tempo de preparo em minutos
     */
    public Receita(String nome, String preparo, String tempo) {
        this.nome = nome;
        this.preparo = preparo;
        this.tempo = tempo;
    }

    // Getters e Setters

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPreparo() {
        return preparo;
    }

    public void setPreparo(String preparo) {
        this.preparo = preparo;
    }

    public String getTempo() {
        return tempo;
    }

    public void setTempo(String tempo) {
        this.tempo = tempo;
    }

    /**
     * Método para retornar uma representação em String da receita
     * Este será o texto exibido no ListView
     */
    @Override
    public String toString() {
        return nome + " - " + tempo + " minutos";
    }
}
