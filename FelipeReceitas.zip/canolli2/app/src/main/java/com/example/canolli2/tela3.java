package com.example.canolli2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class tela3 extends AppCompatActivity {

    // Declaração dos componentes da interface
    private Button botaoIncluir;
    private ListView listaReceitas;
    private String emailUsuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Habilita o modo Edge-to-Edge (tela cheia)
        EdgeToEdge.enable(this);

        // Define o layout da activity
        setContentView(R.layout.activity_tela3);

        // Configura o listener para ajustar padding com as barras do sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Recebe os dados do usuário logado
        receberDadosUsuario();

        // Inicializa os componentes da interface
        inicializarComponentes();

        // Configura os eventos dos botões
        configurarEventos();

        // Exibe mensagem de boas-vindas
        exibirBoasVindas();
    }

    /**
     * Método para receber os dados do usuário da tela de login
     */
    private void receberDadosUsuario() {
        // Obtém o Intent que iniciou esta Activity
        Intent intent = getIntent();

        // Recupera o email passado pela MainActivity
        if (intent.hasExtra("email")) {
            emailUsuario = intent.getStringExtra("email");
        } else {
            emailUsuario = "Usuário";
        }
    }

    /**
     * Método para inicializar todos os componentes da interface
     */
    private void inicializarComponentes() {
        // Vincula os componentes do layout aos objetos Java
        botaoIncluir = findViewById(R.id.BotaoIncluir);
        // listaReceitas = findViewById(R.id.ListaReceitas); // Adicione o ID no ListView se necessário
    }

    /**
     * Método para configurar os eventos de clique dos botões
     */
    private void configurarEventos() {
        // Configura o evento de clique do botão Incluir (+)
        botaoIncluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incluirNovaReceita();
            }
        });
    }

    /**
     * Método para exibir mensagem de boas-vindas ao usuário
     */
    private void exibirBoasVindas() {
        // Exibe uma mensagem de boas-vindas com o email do usuário
        Toast.makeText(this, "Bem-vindo(a) ao Felipe Receitas, " + emailUsuario + "!",
                Toast.LENGTH_LONG).show();
    }

    /**
     * Método para incluir uma nova receita
     */
    private void incluirNovaReceita() {
        // TODO: Criar a tela de incluir receita e navegar para ela
        Toast.makeText(this, "Incluir nova receita...", Toast.LENGTH_SHORT).show();

        // Exemplo de navegação (quando criar a tela de nova receita):
         Intent intent = new Intent(tela3.this, Tela4.class);
         startActivity(intent);
    }

    /**
     * Método para fazer logout e voltar para a tela de login
     */
    private void fazerLogout() {
        // Limpa qualquer dado de sessão se necessário

        // Mensagem de confirmação
        Toast.makeText(this, "Logout realizado com sucesso", Toast.LENGTH_SHORT).show();

        // Volta para a MainActivity (tela de login)
        Intent intent = new Intent(tela3.this, MainActivity.class);

        // Limpa o histórico de navegação para que o usuário não volte com o botão "voltar"
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        startActivity(intent);

        // Finaliza a Tela3
        finish();
    }

    /**
     * Sobrescreve o comportamento do botão voltar
     * Para evitar que o usuário volte para a tela de login acidentalmente
     */
    @Override
    public void onBackPressed() {
        // Mostra mensagem informando que não pode voltar
        Toast.makeText(this, "Pressione novamente para sair", Toast.LENGTH_SHORT).show();

        // Não chama super.onBackPressed() para desabilitar o botão voltar
        // Se quiser permitir voltar, descomente a linha abaixo:
         super.onBackPressed();
    }
}