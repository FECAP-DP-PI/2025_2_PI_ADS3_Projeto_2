package com.example.canolli2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Tela2 extends AppCompatActivity {

    // Declaração dos componentes da interface
    private EditText campoNome;
    private EditText campoCpf;
    private EditText campoEmail;
    private EditText campoSenha;
    private Button botaoConfirmar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Habilita o modo Edge-to-Edge (tela cheia)
        EdgeToEdge.enable(this);

        // Define o layout da activity
        setContentView(R.layout.activity_tela2);

        // Configura o listener para ajustar padding com as barras do sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicializa os componentes da interface
        inicializarComponentes();

        // Configura os eventos dos botões
        configurarEventos();
    }

    /**
     * Método para inicializar todos os componentes da interface
     */
    private void inicializarComponentes() {
        // Vincula os componentes do layout aos objetos Java
        campoNome = findViewById(R.id.CampoNomet2);
        campoCpf = findViewById(R.id.CampoCpf);
        campoEmail = findViewById(R.id.CampoemailT2);
        campoSenha = findViewById(R.id.CampoSenhat2);
        botaoConfirmar = findViewById(R.id.button);
    }

    /**
     * Método para configurar os eventos de clique dos botões
     */
    private void configurarEventos() {
        // Configura o evento de clique do botão Confirmar
        botaoConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cadastrarUsuario();
            }
        });
    }

    /**
     * Método para realizar o cadastro do usuário
     */
    private void cadastrarUsuario() {
        // Obtém o texto digitado nos campos
        String nome = campoNome.getText().toString().trim();
        String cpf = campoCpf.getText().toString().trim();
        String email = campoEmail.getText().toString().trim();
        String senha = campoSenha.getText().toString().trim();

        // Valida se o campo nome não está vazio
        if (nome.isEmpty()) {
            campoNome.setError("Por favor, digite seu nome");
            campoNome.requestFocus();
            return;
        }

        // Valida se o nome tem pelo menos 3 caracteres
        if (nome.length() < 3) {
            campoNome.setError("Nome deve ter pelo menos 3 caracteres");
            campoNome.requestFocus();
            return;
        }

        // Valida se o campo CPF não está vazio
        if (cpf.isEmpty()) {
            campoCpf.setError("Por favor, digite seu CPF");
            campoCpf.requestFocus();
            return;
        }

        // Valida o formato do CPF (11 dígitos)
        if (!validarCpf(cpf)) {
            campoCpf.setError("CPF inválido. Digite apenas números (11 dígitos)");
            campoCpf.requestFocus();
            return;
        }

        // Valida se o campo email não está vazio
        if (email.isEmpty()) {
            campoEmail.setError("Por favor, digite seu email");
            campoEmail.requestFocus();
            return;
        }

        // Valida o formato do email
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            campoEmail.setError("Email inválido");
            campoEmail.requestFocus();
            return;
        }

        // Valida se o campo senha não está vazio
        if (senha.isEmpty()) {
            campoSenha.setError("Por favor, digite sua senha");
            campoSenha.requestFocus();
            return;
        }

        // Valida o tamanho mínimo da senha
        if (senha.length() < 6) {
            campoSenha.setError("A senha deve ter pelo menos 6 caracteres");
            campoSenha.requestFocus();
            return;
        }

        // Se todas as validações passarem, realiza o cadastro
        realizarCadastro(nome, cpf, email, senha);
    }

    /**
     * Método para validar o formato do CPF
     * @param cpf CPF a ser validado
     * @return true se o CPF é válido, false caso contrário
     */
    private boolean validarCpf(String cpf) {
        // Remove caracteres não numéricos
        String cpfLimpo = cpf.replaceAll("[^0-9]", "");

        // Verifica se tem 11 dígitos
        if (cpfLimpo.length() != 11) {
            return false;
        }

        // Verifica se todos os dígitos são iguais (CPF inválido)
        if (cpfLimpo.matches("(\\d)\\1{10}")) {
            return false;
        }

        // Validação básica dos dígitos verificadores
        try {
            // Calcula o primeiro dígito verificador
            int soma = 0;
            for (int i = 0; i < 9; i++) {
                soma += Character.getNumericValue(cpfLimpo.charAt(i)) * (10 - i);
            }
            int primeiroDigito = 11 - (soma % 11);
            if (primeiroDigito >= 10) primeiroDigito = 0;

            // Verifica o primeiro dígito
            if (primeiroDigito != Character.getNumericValue(cpfLimpo.charAt(9))) {
                return false;
            }

            // Calcula o segundo dígito verificador
            soma = 0;
            for (int i = 0; i < 10; i++) {
                soma += Character.getNumericValue(cpfLimpo.charAt(i)) * (11 - i);
            }
            int segundoDigito = 11 - (soma % 11);
            if (segundoDigito >= 10) segundoDigito = 0;

            // Verifica o segundo dígito
            return segundoDigito == Character.getNumericValue(cpfLimpo.charAt(10));

        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Método para realizar o cadastro no sistema
     * @param nome Nome do usuário
     * @param cpf CPF do usuário
     * @param email Email do usuário
     * @param senha Senha do usuário
     */
    private void realizarCadastro(String nome, String cpf, String email, String senha) {
        // Aqui você implementaria a lógica de cadastro
        // Por exemplo: salvar no Firebase, enviar para API, banco de dados local, etc.

        // Feedback ao usuário
        Toast.makeText(this, "Cadastro realizado com sucesso!", Toast.LENGTH_LONG).show();

        // TODO: Implementar cadastro real
        // Exemplo: salvarUsuarioFirebase(nome, cpf, email, senha);

        // Após cadastro bem-sucedido, pode voltar para a tela de login
        // ou redirecionar para a tela principal
        voltarParaLogin();
    }

    /**
     * Método para voltar à tela de login após cadastro
     */
    private void voltarParaLogin() {
        // Finaliza a activity atual e retorna para a MainActivity
        finish();
    }

    /**
     * Método para limpar todos os campos
     */
    private void limparCampos() {
        campoNome.setText("");
        campoCpf.setText("");
        campoEmail.setText("");
        campoSenha.setText("");
        campoNome.requestFocus();
    }
}