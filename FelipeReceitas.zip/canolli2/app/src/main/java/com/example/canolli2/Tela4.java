package com.example.canolli2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Tela4 extends AppCompatActivity {

    // Declaração dos componentes da interface
    private EditText NomeReceita;
    private EditText ModoPreparo;
    private EditText TempoReceita;
    private Button BotaoSalvarReceita;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Habilita o modo Edge-to-Edge (tela cheia)
        EdgeToEdge.enable(this);

        // Define o layout da activity
        setContentView(R.layout.activity_tela4);

        // Configura o listener para ajustar padding com as barras do sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicializa os componentes da interface
        inicializarComponentes();

        // Configura os eventos dos botões
        configurarEventos();
    }

    /**
     * Método para inicializar todos os componentes da interface
     */
    private void inicializarComponentes() {
        // Vincula os componentes do layout aos objetos Java
        NomeReceita = findViewById(R.id.NomeReceita);
        ModoPreparo = findViewById(R.id.ModoPreparo);
        TempoReceita = findViewById(R.id.TempoReceita);
        BotaoSalvarReceita = findViewById(R.id.BotaoSalvarReceita);
    }

    /**
     * Método para configurar os eventos de clique dos botões
     */
    private void configurarEventos() {
        // Configura o evento de clique do botão Salvar
        BotaoSalvarReceita.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvarReceita();
            }
        });
    }

    /**
     * Método para validar e salvar a receita
     */
    private void salvarReceita() {
        // Obtém o texto digitado nos campos
        String nomeReceita = NomeReceita.getText().toString().trim();
        String modoPreparo = ModoPreparo.getText().toString().trim();
        String tempoReceita = TempoReceita.getText().toString().trim();

        // Valida se o campo nome não está vazio
        if (nomeReceita.isEmpty()) {
            NomeReceita.setError("Por favor, digite o nome da receita");
            NomeReceita.requestFocus();
            return;
        }

        // Valida se o nome tem pelo menos 3 caracteres
        if (nomeReceita.length() < 3) {
            NomeReceita.setError("Nome deve ter pelo menos 3 caracteres");
            NomeReceita.requestFocus();
            return;
        }

        // Valida se o campo preparo não está vazio
        if (modoPreparo.isEmpty()) {
            ModoPreparo.setError("Por favor, descreva o modo de preparo");
            ModoPreparo.requestFocus();
            return;
        }

        // Valida se o preparo tem pelo menos 10 caracteres
        if (modoPreparo.length() < 10) {
            ModoPreparo.setError("Modo de preparo muito curto");
            ModoPreparo.requestFocus();
            return;
        }

        // Valida se o campo tempo não está vazio
        if (tempoReceita.isEmpty()) {
            TempoReceita.setError("Por favor, informe o tempo de preparo");
            TempoReceita.requestFocus();
            return;
        }

        // Valida se o tempo é um número válido
        try {
            int tempo = Integer.parseInt(tempoReceita);
            if (tempo <= 0) {
                TempoReceita.setError("Tempo deve ser maior que zero");
                TempoReceita.requestFocus();
                return;
            }
        } catch (NumberFormatException e) {
            TempoReceita.setError("Digite apenas números");
            TempoReceita.requestFocus();
            return;
        }

        // Se todas as validações passarem, envia os dados de volta para a Tela3
        enviarDadosParaTela3(nomeReceita, modoPreparo, tempoReceita);
    }

    /**
     * Método para enviar os dados da receita de volta para a Tela3
     * @param nome Nome da receita
     * @param preparo Modo de preparo da receita
     * @param tempo Tempo de preparo em minutos
     */
    private void enviarDadosParaTela3(String nome, String preparo, String tempo) {
        // Cria um Intent para retornar os dados
        Intent intent = new Intent();

        // Adiciona os dados da receita ao Intent
        intent.putExtra("nome_receita", nome);
        intent.putExtra("preparo_receita", preparo);
        intent.putExtra("tempo_receita", tempo);

        // Define o resultado como OK e anexa o Intent com os dados
        setResult(RESULT_OK, intent);

        // Exibe mensagem de sucesso
        Toast.makeText(this, "Receita salva com sucesso!", Toast.LENGTH_SHORT).show();

        // Finaliza a Tela4 e retorna para a Tela3
        finish();
    }

    /**
     * Método para limpar todos os campos
     */
    private void limparCampos() {
        NomeReceita.setText("");
        ModoPreparo.setText("");
        TempoReceita.setText("");
        NomeReceita.requestFocus();
    }

    /**
     * Sobrescreve o comportamento do botão voltar
     * Pergunta se o usuário realmente quer descartar a receita
     */
    @Override
    public void onBackPressed() {
        // Verifica se há dados digitados
        boolean temDados = !NomeReceita.getText().toString().isEmpty() ||
                !ModoPreparo.getText().toString().isEmpty() ||
                !TempoReceita.getText().toString().isEmpty();

        if (temDados) {
            // Mostra mensagem de aviso
            Toast.makeText(this, "Receita não salva será perdida", Toast.LENGTH_SHORT).show();
        }

        // Permite voltar
        super.onBackPressed();
    }
}